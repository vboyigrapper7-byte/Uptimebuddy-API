/**
 * Monitor Hub Authentication Middleware
 * Enforces Access Token validation via Firebase Admin.
 */

const admin = require('../../core/auth/firebase');
const { validateApiKey } = require('./service');
const planService = require('../../core/billing/planService');

/**
 * Standard Auth Guard: Validates Firebase ID Token
 */
async function requireAuth(request, reply) {
    const authHeader = request.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return reply.status(401).send({ error: 'Missing or malformed Authorization header' });
    }

    const idToken = authHeader.split('Bearer ')[1];

    try {
        const decodedToken = await admin.auth().verifyIdToken(idToken);
        
        let res;
        try {
            res = await request.server.db.query(
                'SELECT id, email, name, status_slug, role, tier, plan_id, trial_ends_at, plan_expiry, subscription_id FROM users WHERE email = $1',
                [decodedToken.email]
            );
        } catch (dbErr) {
            request.log.error('Database query failed during auth:', dbErr.message);
            return reply.status(500).send({ error: `Internal database error during authentication: ${dbErr.message}` });
        }

        // Auto-provision PostgreSQL DB user if they authenticated via Firebase but don't exist locally
        if (res.rows.length === 0) {
            try {
                const crypto = require('crypto');
                const placeholderHash = crypto.randomBytes(32).toString('hex');
                // Determine provider from token (firebase property)
                const provider = decodedToken.firebase?.sign_in_provider === 'google.com' ? 'google' : 'email';
                
                res = await request.server.db.query(
                    'INSERT INTO users (email, password_hash, role, provider) VALUES ($1, $2, $3, $4) RETURNING id, email, role, tier, provider',
                    [decodedToken.email, placeholderHash, 'customer', provider]
                );
            } catch (insertErr) {
                request.log.error('Failed to auto-provision user:', insertErr.message);
                return reply.status(500).send({ error: `Failed to create user account locally: ${insertErr.message}` });
            }
        }

        request.user = res.rows[0];
    } catch (err) {
        request.log.error(`Auth failed: ${err.message}`);
        return reply.status(401).send({ error: 'Session expired or invalid token' });
    }
}

/**
 * Role Guard: Ensures user has required role (e.g. 'admin')
 */
function requireRole(role) {
    return async (request, reply) => {
        if (!request.user || request.user.role !== role) {
            return reply.status(403).send({ error: `Forbidden: Requires ${role} permissions` });
        }
    };
}

/**
 * Agent Auth Guard: Validates X-API-KEY header
 */
async function requireApiKey(request, reply) {
    const apiKey = request.headers['x-api-key'];
    if (!apiKey) {
        return reply.status(401).send({ error: 'Missing API Key' });
    }

    const user = await validateApiKey(request.server.db, apiKey);
    if (!user) {
        return reply.status(401).send({ error: 'Invalid or revoked API Key' });
    }
    // Attach agent info to request
    request.user = user;
}

/**
 * Plan Guard: Ensures user has required feature access
 */
function requirePlan(feature) {
    return async (request, reply) => {
        if (!request.user) return reply.status(401).send({ error: 'Auth required' });
        
        const hasAccess = planService.canUseFeature(request.user, feature);
        if (!hasAccess) {
            return reply.status(403).send({ 
                error: `Upgrade required: ${feature.replace(/_/g, ' ')} is not available on your current plan.` 
            });
        }
    };
}

/**
 * Team Role Guard: Ensures user has specific role within a team context
 */
function requireTeamRole(requiredRole) {
    return async (request, reply) => {
        const teamId = request.params.teamId || request.body.teamId;
        if (!teamId) return reply.status(400).send({ error: 'Team ID required' });

        const memberRes = await request.server.db.query(
            'SELECT role FROM team_members WHERE team_id = $1 AND user_id = $2',
            [teamId, request.user.id]
        );

        if (memberRes.rows.length === 0) {
            return reply.status(403).send({ error: 'Forbidden: Not a member of this team' });
        }

        const roleLevels = { 'viewer': 1, 'member': 2, 'admin': 3, 'owner': 4 };
        if (roleLevels[memberRes.rows[0].role] < roleLevels[requiredRole]) {
            return reply.status(403).send({ error: `Forbidden: Requires ${requiredRole} role` });
        }
    };
}

module.exports = { requireAuth, requireRole, requireApiKey, requirePlan, requireTeamRole };
